script.enc 為加密的劇本文字；rules.txt 為自行整理的簡易規則；images 為 PL 版地圖。
